<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.1" tiledversion="2018.09.12" name="tileset" tilewidth="4" tileheight="4" tilecount="256" columns="16">
 <image source="../../../tileset.png" width="64" height="64"/>
</tileset>
